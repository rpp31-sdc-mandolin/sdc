test('adds 1 + 2 to equal 3', () => {
  var sum = 1 + 2;
  expect(sum).toBe(3);
});