const React = require('react');
const Adapter = require('@wojtekmaj/enzyme-adapter-react-17');
const Enzyme = require('enzyme');
const { shallow, mount, render } = Enzyme;

Enzyme.configure({ adapter: new Adapter() });

import RatingsReviews from '../../client/src/components/Reviews/Index.jsx';


describe('Ratings and Reviews component', () => {
  let wrapper = shallow(<RatingsReviews product_id={59554}/>);

  it('should render to the page', ()=> {
    expect(wrapper).toHaveLength(1);
  });

});
