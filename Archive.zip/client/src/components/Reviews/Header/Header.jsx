import React from 'react';

const Header = props => {
  return (
    <h1 id='Header'>
      {'RATINGS & REVIEWS'}
    </h1>
  );
};

export default Header;