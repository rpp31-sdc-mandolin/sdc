import React from 'react';

const SiteMessage = props => {
  return (
    <div id='SiteMessage'>
      SITE-WIDE ANNOUNCEMENT MESSAGE! SALE / DISCOUNT OFFER - NEW PRODUCT HIGHLIGHT
    </div>
  );
};

export default SiteMessage;