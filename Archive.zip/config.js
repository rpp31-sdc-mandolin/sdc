module.exports = {
  API_KEY:'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'
}