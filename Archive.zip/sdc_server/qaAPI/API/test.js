const { createClient }  = require('redis');

(async () => {
  const client = createClient();

  client.on('error', (err) => console.log('Redis Client Error', err));

  await client.connect();

  await client.set('key', 'value');
  console.log('set...\n');
  var value = await client.get('key');
  console.log('got ' + value);
  await client.del('key');
  value = await client.get('key');
  console.log('got Again' + value);

})();

